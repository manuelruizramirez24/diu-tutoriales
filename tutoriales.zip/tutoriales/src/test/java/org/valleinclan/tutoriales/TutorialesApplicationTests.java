package org.valleinclan.tutoriales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TutorialesApplicationTests {

	@Test
	void contextLoads() {
	}

}
