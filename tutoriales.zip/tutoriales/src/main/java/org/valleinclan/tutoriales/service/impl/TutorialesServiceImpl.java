package org.valleinclan.tutoriales.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.valleinclan.tutoriales.model.TutorialesVO;
import org.valleinclan.tutoriales.repository.TutorialesRepository;
import org.valleinclan.tutoriales.service.TutorialesService;

import java.util.List;
import java.util.Optional;

@Service
public class TutorialesServiceImpl implements TutorialesService {

    @Autowired
    private TutorialesRepository tutorialesRepository;

    @Override
    public List<TutorialesVO> getAllTutorials(String title) {
        if (title != null) {
            return tutorialesRepository.findByTitleContaining(title);
        } else {
            return tutorialesRepository.findAll();
        }
    }

    @Override
    public Optional<TutorialesVO> getTutorialById(String id) {
        return tutorialesRepository.findById(id);
    }

    @Override
    public List<TutorialesVO> findByPublished(boolean published) {
        return tutorialesRepository.findByPublishedTrue(published);
    }

    @Override
    public TutorialesVO save(TutorialesVO tutorial) {
        return tutorialesRepository.save(tutorial);
    }

    @Override
    public TutorialesVO updateTutorial(TutorialesVO tutorial, String id) {
        Optional<TutorialesVO> existingTutorialOptional = tutorialesRepository.findById(id);

        if (existingTutorialOptional.isPresent()) {
            TutorialesVO existingTutorial = existingTutorialOptional.get();
            existingTutorial.setTitle(tutorial.getTitle());
            existingTutorial.setDescription(tutorial.getDescription());
            existingTutorial.setPublished(tutorial.isPublished());

            return tutorialesRepository.save(existingTutorial);
        } else {
            // Manejar el caso cuando no se encuentra el tutorial con el ID proporcionado
            return null;
        }
    }

    @Override
    public void deleteTutorial(String id) {
        tutorialesRepository.deleteById(id);
    }

    @Override
    public void deleteAllTutorials() {
        tutorialesRepository.deleteAll();
    }
}
