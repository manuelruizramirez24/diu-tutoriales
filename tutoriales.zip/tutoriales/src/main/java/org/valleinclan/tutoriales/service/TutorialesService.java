package org.valleinclan.tutoriales.service;

import org.valleinclan.tutoriales.model.TutorialesVO;

import java.util.List;
import java.util.Optional;

public interface TutorialesService {
    List<TutorialesVO> getAllTutorials(String title);
    Optional<TutorialesVO> getTutorialById(String id);
    List<TutorialesVO> findByPublished(boolean published); // Corregido el nombre del método
    TutorialesVO save(TutorialesVO tutorial);
    TutorialesVO updateTutorial(TutorialesVO tutorial, String id);
    void deleteTutorial(String id);
    void deleteAllTutorials();
}
