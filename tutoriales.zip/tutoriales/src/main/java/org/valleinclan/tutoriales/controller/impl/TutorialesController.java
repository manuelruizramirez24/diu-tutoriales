package org.valleinclan.tutoriales.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.valleinclan.tutoriales.model.TutorialesVO;
import org.valleinclan.tutoriales.service.TutorialesService;


import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1")
public class TutorialesController {

    @Autowired
    private TutorialesService tutorialesService;

    @GetMapping("/tutorials")
    public List<TutorialesVO> getAllTutorials(@RequestParam(required = false) String title) {
        return tutorialesService.getAllTutorials(title);
    }

    @GetMapping("/tutorials/{id}")
    public Optional<TutorialesVO> getTutorialById(@PathVariable String id) {
        return tutorialesService.getTutorialById(id);
    }

    @GetMapping("/tutorials/published")
    public List<TutorialesVO> getPublishedTutorials() {
        return tutorialesService.findByPublished(true);
    }

    @PostMapping("/tutorials")
    public TutorialesVO createTutorial(@RequestBody TutorialesVO tutorial) {
        return tutorialesService.save(tutorial);
    }

    @PutMapping("/tutorials/{id}")
    public TutorialesVO updateTutorial(@PathVariable String id, @RequestBody TutorialesVO updatedTutorial) {
        return tutorialesService.updateTutorial(updatedTutorial, id);
    }

    @DeleteMapping("/tutorials/{id}")
    public void deleteTutorial(@PathVariable String id) {
        tutorialesService.deleteTutorial(id);
    }

    @DeleteMapping("/tutorials")
    public void deleteAllTutorials() {
        tutorialesService.deleteAllTutorials();
    }
}
