package org.valleinclan.tutoriales.model;

public class Tutoriales {
}
